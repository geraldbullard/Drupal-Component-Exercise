<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'tui', 'song', 'shi', 'tao', 'pang', 'hou', 'ni', 'dun', 'jiong', 'xuan', 'xun', 'bu', 'you', 'xiao', 'qiu', 'tou',
  0x10 => 'zhu', 'qiu', 'di', 'di', 'tu', 'jing', 'ti', 'dou', 'yi', 'zhe', 'tong', 'guang', 'wu', 'shi', 'cheng', 'su',
  0x20 => 'zao', 'qun', 'feng', 'lian', 'suo', 'hui', 'li', 'gu', 'lai', 'ben', 'cuo', 'jue', 'beng', 'huan', 'dai', 'lu',
  0x30 => 'you', 'zhou', 'jin', 'yu', 'chuo', 'kui', 'wei', 'ti', 'yi', 'da', 'yuan', 'luo', 'bi', 'nuo', 'yu', 'dang',
  0x40 => 'sui', 'dun', 'sui', 'yan', 'chuan', 'chi', 'ti', 'yu', 'shi', 'zhen', 'you', 'yun', 'e', 'bian', 'guo', 'e',
  0x50 => 'xia', 'huang', 'qiu', 'dao', 'da', 'wei', 'nan', 'yi', 'gou', 'yao', 'chou', 'liu', 'xun', 'ta', 'di', 'chi',
  0x60 => 'yuan', 'su', 'ta', 'qian', 'ma', 'yao', 'guan', 'zhang', 'ao', 'shi', 'ca', 'chi', 'su', 'zao', 'zhe', 'dun',
  0x70 => 'di', 'lou', 'chi', 'cuo', 'lin', 'zun', 'rao', 'qian', 'xuan', 'yu', 'yi', 'wu', 'liao', 'ju', 'shi', 'bi',
  0x80 => 'yao', 'mai', 'xie', 'sui', 'hai', 'zhan', 'teng', 'er', 'miao', 'bian', 'bian', 'la', 'li', 'yuan', 'yao', 'luo',
  0x90 => 'li', 'yi', 'ting', 'deng', 'qi', 'yong', 'shan', 'han', 'yu', 'mang', 'ru', 'qiong', 'wan', 'kuang', 'fu', 'kang',
  0xA0 => 'bin', 'fang', 'xing', 'na', 'xin', 'shen', 'bang', 'yuan', 'cun', 'huo', 'xie', 'bang', 'wu', 'ju', 'you', 'han',
  0xB0 => 'tai', 'qiu', 'bi', 'pi', 'bing', 'shao', 'bei', 'wa', 'di', 'zou', 'ye', 'lin', 'kuang', 'gui', 'zhu', 'shi',
  0xC0 => 'ku', 'yu', 'gai', 'he', 'qie', 'zhi', 'ji', 'huan', 'hou', 'xing', 'jiao', 'xi', 'gui', 'nuo', 'lang', 'jia',
  0xD0 => 'kuai', 'zheng', 'lang', 'yun', 'yan', 'cheng', 'dou', 'xi', 'lu', 'fu', 'wu', 'fu', 'gao', 'hao', 'lang', 'jia',
  0xE0 => 'geng', 'jun', 'ying', 'bo', 'xi', 'bei', 'li', 'yun', 'bu', 'xiao', 'qi', 'pi', 'qing', 'guo', 'zhou', 'tan',
  0xF0 => 'zou', 'ping', 'lai', 'ni', 'chen', 'you', 'bu', 'xiang', 'dan', 'ju', 'yong', 'qiao', 'yi', 'dou', 'yan', 'mei',
];
